delete from matching;

Insert into matching values(match_count.nextval, 1, 'park', 'lee', 'moon', 'kim', 'jung', null, null);

Insert into matching values(match_count.nextval, 2, 'park', 'lee', 'moon', 'kim', 'jung', null, null);

Insert into matching values(match_count.nextval, 3, 'park', 'lee', 'moon', 'kim', 'jung', null, null);

Insert into matching values(match_count.nextval, 4, 'park', 'lee', 'moon', 'kim', 'jung', null, null);

Insert into matching values(match_count.nextval, 2, 'park', '', '', '', '', null, null);

Insert into matching values(match_count.nextval, 5, 'kim', 'lee', 'jung', '', '', null, null);

Insert into matching values(match_count.nextval, 6, 'park', 'lee', 'moon', 'kim', '', null, null);

Insert into matching values(match_count.nextval, 8, 'kim', 'jung', 'moon', '', '', null, null);

commit;


