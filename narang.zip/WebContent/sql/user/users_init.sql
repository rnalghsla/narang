delete from users;

Insert into users values('admin', 'admin', '������', 'W', '99', '01099999999', '0099@naver.com', 0, '/images/admin.jpg', 'A');

Insert into users values('park','1234','�ڿ���','W', 24, '01067873131','5910342@naver.com', 0, '/images/my.jpg','G');

Insert into users values('moon','1234','���¸�','W', 24, '01012340001', '0001@naver.com', 0, '/images/my.jpg', 'G');

Insert into users values('lee', '1234', '���ϴ�', 'W', 24, '01012340002', '0002@naver.com', 0, '/images/my.jpg', 'G');

Insert into users values('kim', '1234', '������', 'W', 24, '01012340003', '0003@naver.com', 0, '/images/my.jpg', 'G');

Insert into users values('jung', '1234', '������', 'W', '24', '01012340004', '0004@naver.com', 0, '/images/my.jpg', 'G');

Insert into users values('black', '1234', '�ȴ�', 'M', '32', '01032187204', '0black@naver.com', 5, '/images/black.jpg', 'B');

Insert into users values('naver', '1234', '���̹�ȸ��', 'M', '12', '01012621513', '0naver@naver.com', 0, '/images/naver.jpg', 'N');

Insert into users values('sky', null, null, null, null, null, null, 0, null, 'X');

Insert into users values('del', '1234', 'a', 'W', '99', '01099999999', '0099@naver.com', 0, '/images/admin.jpg', 'G');

commit;


