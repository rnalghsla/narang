delete from notify;

Insert into notify values(  '1',  'jung',  'park',  'board', 1 );

Insert into notify values(  '2',  'kim',  'jung', 'comment', 1  );

Insert into notify values(  '3',  'lee',  'moon',  'review', 1 );

commit;