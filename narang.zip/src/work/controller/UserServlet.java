package work.controller;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work.model.dao.BoardDao;
import work.model.dao.CommentDao;
import work.model.dao.MatchingDao;
import work.model.dao.UserDao;
import work.model.dto.Board;
import work.model.dto.Comment;
import work.model.dto.User;


/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends HttpServlet {
	// �α��� ��û ���� �޼���
	String loginUserId = null;

	/**
	 * �α��� �޼���
	 * 
	 * @param request ��û
	 * @param response ����
	 * @throws ServletException ����ó��
	 * @throws IOException ����ó��
	 */
	protected void login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userId = request.getParameter("userId");
		loginUserId = userId;
		String userPw = request.getParameter("userPw");
		HashMap<String, String> loginmap = UserDao.login(userId, userPw);
		if (loginmap.get("name") != null) {
			HttpSession session = request.getSession();
			session.setAttribute("userId", userId);
			session.setAttribute("name", loginmap.get("name"));
			session.setAttribute("grade", loginmap.get("grade"));
			request.getRequestDispatcher("user\\user\\login.jsp").forward(request, response);
		} else {
			RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\login.jsp");
			nextview.forward(request, response);

		}
	}
	
	/**
	 * �α׾ƿ�
	 * 
	 * @param request ��û
	 * @param response ����
	 * @throws ServletException ����ó��
	 * @throws IOException ����ó��
	 */
	protected void logout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
			session.invalidate();
			RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\index.jsp");
			nextview.forward(request, response);
		}
	
	protected User selectMyUserInfo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String userId = (String) session.getAttribute("userId");
		User user = UserDao.selectMyUserInfo();
		request.setAttribute("user", user);
		RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\selectMyUserInfo.jsp");
		nextview.forward(request, response);
		return user;
	}
	
	protected  ArrayList<Board> selectMyBoard(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Board> board = BoardDao.selectMyBoard(loginUserId);
		request.setAttribute("board", board);
		RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\selectMyBoard.jsp");
		nextview.forward(request, response);
		return board;
	}
	
	protected  ArrayList<Board> selectMyMatchingBoard(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Board> matchingBoard = MatchingDao.selectMyMatchingBoard(loginUserId);
		request.setAttribute("matchingBoard", matchingBoard);
		RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\selectMyMatchingBoard.jsp");
		nextview.forward(request, response);
		return matchingBoard;
	}
	
	protected  ArrayList<Comment> selectMyComment(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Comment> comment = CommentDao.selectMyComment(loginUserId);
		request.setAttribute("comment", comment);
		RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\selectMyComment.jsp");
		nextview.forward(request, response);
		return comment;
	}
	
	
	protected User updateMyUserInfopage(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String userId = (String) session.getAttribute("userId");
		User user = UserDao.selectMyUserInfo();
		request.setAttribute("user", user);
		RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\updateMyUserInfo.jsp");
		nextview.forward(request, response);
		return user;
	}
	
	protected void updateMyUserInfo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			String mobile = request.getParameter("chmobile");
			String email = request.getParameter("chemail");
			String age = request.getParameter("chage");
			String gender = request.getParameter("chgender");
			int changeName = UserDao.updateMyUserInfo(loginUserId, gender, age, mobile,email );
			if (changeName > 0) {
				request.setAttribute("message", "�������� ���������� ����Ǿ����ϴ�.");
				RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\MyPageInfo.jsp");
				nextview.forward(request, response);
			} else {
				request.setAttribute("message", "�������� ������� �ʾҽ��ϴ�.");
				RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\MyPageInfo.jsp");
				nextview.forward(request, response);
			}
	}
	
	protected void updateUserPw(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userPw = request.getParameter("userPw");
		String change_pw = request.getParameter("change_pw");
		String ch = request.getParameter("ch");
		if (userPw == null || userPw.trim().length() == 0 || change_pw == null || change_pw.trim().length() == 0
				|| ch == null || ch.trim().length() == 0) {
			request.setAttribute("message", "��� ������ �Է��Ͻñ� �ٶ��ϴ�.");
			RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\MyPageInfo.jsp");
			nextview.forward(request, response);
		}
		HttpSession session = request.getSession();
		int changePw = UserDao.updateUserPw(loginUserId, userPw, change_pw);
		System.out.println(changePw);
		if (changePw > 0) {
			if (ch.equals("HYSUCF")) {
				session.invalidate();
				request.setAttribute("message", "��й�ȣ�� ���������� ����Ǿ����ϴ�.");
				RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\MyPageInfo.jsp");
				nextview.forward(request, response);
			} else {
				request.setAttribute("message", "�ùٸ� ���ȹ��ڸ� �Է����ּ���.");
				RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\MyPageInfo.jsp");
				nextview.forward(request, response);
			}
		} else {
			request.setAttribute("message", "��й�ȣ�� ������� �ʾҽ��ϴ�.");
			RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\MyPageInfo.jsp");
			nextview.forward(request, response);
		}
	}
	
	protected void updateUserGradeNone(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			String userPw = request.getParameter("userPw");
			HttpSession session = request.getSession();
			int delete = UserDao.updateUserGradeNone(loginUserId, userPw);
			if (delete > 0) {
				session.invalidate();
				RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\index.jsp");
				nextview.forward(request, response);
			} else {
				request.setAttribute("message", "Ż�� �̷������ �ʾҽ��ϴ�. ��й�ȣ�� �ٽ��ѹ� �Է����ּ���.");
				RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\MyPageInfo.jsp");
				nextview.forward(request, response);
			}
	}
	
	protected void goupdateUserGradeNone(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\updateUserGradeNone.jsp");
		nextview.forward(request, response);
	}
	
	protected void goupdateUserPw(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher nextview = request.getRequestDispatcher("user\\user\\updateUserPw.jsp");
		nextview.forward(request, response);
	}
	

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserServlet() {
		super();
	}

	/**
	 * get post�� ���� ���� ��û �޼��� 
	 * 
	 * @param request ��û
	 * @param response ����
	 * @throws ServletException ����ó��
	 * @throws IOException ����ó��
	 */
	protected void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getParameter("action");
		System.out.println("action : "+action);
		if (action != null) {
			switch (action) {
			case "login":
				login(request, response);
				break;
			case "selectMyUserInfo":
				selectMyUserInfo(request, response);
				break;
			case "selectMyBoard":
				selectMyBoard(request, response);
				break;
			case "selectMyMatchingBoard":
				selectMyMatchingBoard(request, response);
				break;
			case "updateMyUserInfopage":
				updateMyUserInfopage(request, response);
				break;
			case "updateMyUserInfo":
				updateMyUserInfo(request, response);
				break;
			case "selectMyComment":
				selectMyComment(request, response);
				break;
			case "updateUserPw":
				updateUserPw(request, response);
				break;
			case "goupdateUserPw":
				goupdateUserPw(request, response);
				break;
			case "updateUserGradeNone":
				updateUserGradeNone(request, response);
				break;
			case "goupdateUserGradeNone":
				goupdateUserGradeNone(request, response);
				break;
			default:
				System.out.println("�������� �ʴ� ��û�Դϴ�.");
				break;
			}
		} else {

		}

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("euc-kr");
		process(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("euc-kr");
		process(request, response);
	}

}

